﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using Android.App;
using Android.Content;
using Android.OS;
using Android.Runtime;
using Android.Views;
using Android.Widget;
using SQLite;

namespace BudgetXtreme.Tables
{
    [Table("User")]
    class Users
    {
        // PrimaryKey must be numeric
        [PrimaryKey, AutoIncrement, Column("UserID")]
        public int UserID { get; set; }

        [MaxLength(50), Unique, NotNull, Column("Username")]
        public string Username { get; set; }

        [MaxLength(50), NotNull, Column("Password")]
        public string Password { get; set; }

        [MaxLength(50), NotNull, Column("FirstName")]
        public string FirstName { get; set; }

        [MaxLength(50), NotNull, Column("LastName")]
        public string LastName { get; set; }
    }
}