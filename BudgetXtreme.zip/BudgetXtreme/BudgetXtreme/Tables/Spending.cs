﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using Android.App;
using Android.Content;
using Android.OS;
using Android.Runtime;
using Android.Views;
using Android.Widget;
using SQLite;

namespace BudgetXtreme.Tables
{
    [Table("Spending")]
    class Spending
    {
        // PrimaryKey must be numeric
        [PrimaryKey, AutoIncrement, Column("BudgetID")]
        public int SpendingID { get; set; }

        [NotNull, Column("SpendItemAmount")]
        public double SpendItemAmount { get; set; }

        [NotNull, Column("UpdatedBudgetAmount")]
        public double UpdatedBudgetAmount { get; set; }


        // Getting an error for making the foreign key when this worked in my app
        //[ForeignKey(typeof(Users))]     // Specify the foreign key
        //public int UserID { get; set; }
    }
}