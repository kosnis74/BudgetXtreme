﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using Android.App;
using Android.Content;
using Android.OS;
using Android.Runtime;
using Android.Views;
using Android.Widget;
using SQLite;

namespace BudgetXtreme.Tables
{
    [Table("Budget")]
    class Budget
    {
        // PrimaryKey must be numeric
        [PrimaryKey, AutoIncrement, Column("BudgetID")]
        public int BudgetID { get; set; }

        [NotNull, Column("BudgetAmount")]
        public double BudgetAmount { get; set; }

        [NotNull, Column("TimeFrame")]
        public DateTime TimeFrame { get; set; }


        // Getting an error for making the foreign key when this worked in my app
        //[ForeignKey(typeof(Users))]     // Specify the foreign key
        //public int UserID { get; set; }
    }
}