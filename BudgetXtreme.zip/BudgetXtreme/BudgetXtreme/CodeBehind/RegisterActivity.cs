﻿/***********************************************************************
* Project           : Budget Xtreme
*
* Program name      : RegisterActivity.cs
*
* Author            : Scott Kosnicki, Emmanuel Mercado, Tess Miller,
*                     Matthew Vanden Hogen
*
* Date created      : 4/7/2018
*
* Purpose           : This requests the user to enter a username, email,
*                     and password. Then stores this information in the
*                     database
************************************************************************/

using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;

using Android.App;
using Android.Content;
using Android.OS;
using Android.Runtime;
using Android.Views;
using Android.Widget;
using BudgetXtreme.Tables;
using SQLite;

namespace BudgetXtreme
{
    [Activity(Label = "RegisterActivity")]
    public class RegisterActivity : Activity
    {
        // Declaring UI
        EditText txtFirstName;
        EditText txtLastName;
        EditText txtUsername;
        EditText txtPassword;
        Button btnRegister;

        protected override void OnCreate(Bundle savedInstanceState)
        {
            base.OnCreate(savedInstanceState);

            // Set our view to the register layout
            SetContentView(Resource.Layout.Register);

            // Assigning UI
            txtFirstName = FindViewById<EditText>(Resource.Id.txtFirstName);
            txtLastName = FindViewById<EditText>(Resource.Id.txtLastName);
            txtUsername = FindViewById<EditText>(Resource.Id.txtUsername);
            txtPassword = FindViewById<EditText>(Resource.Id.txtPassword);
            btnRegister = FindViewById<Button>(Resource.Id.btnRegister);
            btnRegister.Click+= BtnRegister_Click;
        }

void BtnRegister_Click(object sender, EventArgs e)
        {
            try   
        {  
            string dpPath = Path.Combine(System.Environment.GetFolderPath(System.Environment.SpecialFolder.Personal), "BudgetDatabase.db3");  
            var db = new SQLiteConnection(dpPath);  

            db.CreateTable < Users > ();
                Users tbl = new Users
                {
                    FirstName = txtFirstName.Text.ToLower(),
                    LastName = txtLastName.Text,
                    Username = txtUsername.Text,
                    Password = txtPassword.Text
                };
                db.Insert(tbl);  

            Toast.MakeText(this, "Record Added Successfully...,", ToastLength.Short).Show();  // For our testing purposes

        } catch (Exception ex) {  
            Toast.MakeText(this, ex.ToString(), ToastLength.Short).Show();  
        }  
        }
    }
}