﻿/***********************************************************************
* Project           : Budget Xtreme
*
* Program name      : LoginActivity.cs
*
* Author            : Scott Kosnicki, Emmanuel Mercado, Tess Miller,
*                     Matthew Vanden Hogen
*
* Date created      : 4/7/2018
*
* Purpose           : This checks if there is an existing database and 
*                     if not it creates one. Then requests the users 
*                     username and password and verifies it with the
*                     the database. If correct logs the user in, if not
*                     alerts the user and requests valid credentials.
************************************************************************/

using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;

using Android.App;
using Android.Content;
using Android.OS;
using Android.Runtime;
using Android.Views;
using Android.Widget;
using BudgetXtreme.Tables;
using SQLite;

namespace BudgetXtreme.CodeBehind
{
    [Activity(Label = "LoginActivity", MainLauncher = true)]
    public class LoginActivity : Activity
    {
        // Declaring UI
        EditText txtUsername;
        EditText txtPassword;
        Button btnLogin;
        Button btnRegister;

        protected override void OnCreate(Bundle savedInstanceState)
        {
            base.OnCreate(savedInstanceState);

            // Set our view to the login layout
            SetContentView(Resource.Layout.Login);

            // Assigning UI
            txtUsername = FindViewById<EditText>(Resource.Id.txtUsername);
            txtPassword = FindViewById<EditText>(Resource.Id.txtPassword);
            btnLogin = FindViewById<Button>(Resource.Id.btnRegister);
            btnLogin.Click+= BtnLogin_Click;
            btnRegister.Click+= BtnRegister_Click;
            CreateDB(); // Create the database if it does not already exist
        }

void BtnLogin_Click(object sender, EventArgs e)
        {
            try  
        {  
            string dpPath = Path.Combine(System.Environment.GetFolderPath(System.Environment.SpecialFolder.Personal), "BudgetDatabase.db3"); //Call Database  
            var db = new SQLiteConnection(dpPath);  
            var data = db.Table < Users > (); //Call Table  

            var QueryTest = data.Where(x => x.Username == txtUsername.Text.ToLower() && x.Password == txtPassword.Text).FirstOrDefault(); //Linq Query  
            if (QueryTest != null)  
            {
                    SetContentView(Resource.Layout.Main);  // Set the View to the main screen
            }  
            else  
            {  
                Toast.MakeText(this, "Username or Password invalid", ToastLength.Short).Show();  
            }  
        }  
        catch (Exception ex)  
        {  
            Toast.MakeText(this, ex.ToString(), ToastLength.Short).Show();  
        }  

        }

void BtnRegister_Click(object sender, EventArgs e)
        {
            // Set the View the the Register Page
            SetContentView(Resource.Layout.Register);

        }

public string CreateDB()  
    {  
        var output = "";  
        output += "Creating Databse if it doesnt exists";  
        string dpPath = Path.Combine(System.Environment.GetFolderPath(System.Environment.SpecialFolder.Personal), "BudgetDatabase.db3"); //Create New Database  
        var db = new SQLiteConnection(dpPath);  
        output += "\n Database Created....";  
        return output;  
    } 
    }
}